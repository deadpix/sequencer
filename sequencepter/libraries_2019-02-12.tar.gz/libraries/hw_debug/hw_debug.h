#ifndef __HW_DEBUG_H__
#define __HW_DEBUG_H__

#if defined(ARDUINO) && ARDUINO >= 100
	#include <Arduino.h>
#else
	#include <WProgram.h>
#endif


#include <string.h>


class dbg {
	private:
		dbg(){};
		~dbg(){};
	public:
		static void print(const String &s){
			Serial.print(s);
		};
		static void print(long n){
			Serial.print(n);
		};
		static void println(const String &s){
			Serial.println(s);
		};
		static void println(long n){
			Serial.println(n);
		};
		static void printf(const char *format, ...){
		};
};

#endif
